var s = ""
s += "<OBJECT id=HWPostil1 align='middle' style='LEFT: 0px; WIDTH: 100%; TOP: 0px; HEIGHT: 100%'"
s += "classid=clsid:FF1FE7A0-0578-4FEE-A34E-FB21B277D561 codebase=../js/HWPostil_V3074.cab#version=3,0,7,4>"
s += "<PARAM NAME='_Version' VALUE='65536'>"
s += "<PARAM NAME='_ExtentX' VALUE='17410'>"
s += "<PARAM NAME='_ExtentY' VALUE='10874'>"
s += "<PARAM NAME='_StockProps' VALUE='0'>"
s += "</OBJECT>"
document.write(s) 