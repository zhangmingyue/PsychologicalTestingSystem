var s = ""
s += "<object id=WebOffice1 height=768 width='100%' height='100%' style='LEFT: 0px; TOP: 0px'  classid='clsid:E77E049B-23FC-4DB8-B756-60529A35FAD5' codebase='js/weboffice_v6.0.5.0.cab#Version=6,0,5,0'>"
s +="<param name='_ExtentX' value='6350'><param name='_ExtentY' value='6350'>"
s +="</OBJECT>"
document.write(s)