var _hmt = _hmt || [];
(function() {
  _hmt.push(['_setAccount', 'd2abe42fa456dc1fead1fb628c78e264']);
  var _hmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
  var _hm = document.createElement("script");
  _hm.src = _hmProtocol + "hm.baidu.com/hm.js?d2abe42fa456dc1fead1fb628c78e264";
  var _s = document.getElementsByTagName("script")[0];
  _s.parentNode.insertBefore(_hm, _s);
})();
var JaxWeiche = (function(){
    var __SSID = '';
    var __BD_PROTOCOL = (navigator.userAgent.indexOf('weiche__') < 0)?'bd-martin':'bd-webview'; //兼容weiche3.5版本

    var __invokeShareFeedback = function(shareID,status){};

    function __invokeAPP(callbackFuncName,args){
        args = args || '';
        location.href = __BD_PROTOCOL+'://get_ssid?callback='+callbackFuncName+'&args='+args;
    }

    function __invokeJS(funcName,ssid,args){
      __SSID = ssid;
      window[funcName](args);
    }

    function __getSSID(){
        return __SSID;
    }

    function __invokeAppShare(shareArgs){
        var channel = shareArgs.channel || 'timeline';
        var link = encodeURIComponent((shareArgs.link || location.href));
        var title = shareArgs.title || '';
        var summary = shareArgs.summary || '';
        var imgUrl = encodeURIComponent((shareArgs.imgUrl || ''));
        var shareID = shareArgs.shareID || '';
        if(typeof(shareArgs.callback) == 'function'){
            shareArgs.callback();
        }
        location.href = __BD_PROTOCOL+'://invoke_share?channel='+channel+'&link='+link+'&title='+title+'&summary='+summary+'&imgurl='+imgUrl+'&shareid='+shareID;
    }

    function __closeWebview(){
        location.href= __BD_PROTOCOL+'://close_webview';
    }


    function __trackEvent(category, action, opt_label, opt_value){
        opt_label = opt_label || '';
        opt_value = opt_value || '';
        _hmt.push(['_trackEvent', category, action, opt_label, opt_value]);
    }

    function __trackPageview(pageURL){
        pageURL = "/"+pageURL;
        _hmt.push(['_trackPageview', pageURL]);
    }

    return {
        author                  :"JaxWang",
        version                 :"1.1.0",
        getSSID                 :__getSSID,
        setSSID                 :__invokeJS,
        reSendWithNewSSID       :__invokeAPP,
        invokeShareFeedback     :__invokeShareFeedback,
        invokeAppShare          :__invokeAppShare,
        closeWebview            :__closeWebview,
        trackEvent              :__trackEvent,
        trackPV                 :__trackPageview
    };
})();  

function __invokeJS(funcName,ssid,args){  //for app
    JaxWeiche.setSSID(funcName,ssid,args);
}
/*
        status:
         0 用户取消
         1 分享成功
         2 分享失败
         3 授权失败
         4 客户端没有安装对应APP
*/
function __invokeShareFeedback(shareID, status){ //for app
    JaxWeiche.invokeShareFeedback(shareID,status);
}